

using System.Diagnostics;
using System.Windows.Forms.VisualStyles;

namespace Pokemon_Project___VISUAL_STUDIO
{
    public partial class Battle_Menu : Form
    {

        // Size variables

        private Rectangle originalFormSize;
        private Rectangle enemyPokemonOriginalRectangle;
        private Rectangle enemyNameOriginalRectangle;


        // Variable Declaration
        Random rng;

        private Pokemon enemyPokemon; private Pokemon playerPokemon;

        public Battle_Menu()
        {
            InitializeComponent();

            // Creates a new Instance of Random for random number gen
            rng = new();
        }

        // Runs upon loading the Battle screen
        private void Form1_Load(object sender, EventArgs e)
        {


            Message_Box.Text = "";

            enemyPokemon = Pick_Pokemon();
            playerPokemon = Pick_Pokemon();


            Enemy_Health_Bar.Maximum = enemyPokemon.health;
            Enemy_Health_Bar.Value = enemyPokemon.health;

            Player_Health_Bar.Maximum = playerPokemon.health;
            Player_Health_Bar.Value = playerPokemon.health;

            Enemy_Pokemon_Sprite.BackgroundImage = Image.FromFile(enemyPokemon.frontSpritePath);
            Enemy_Pokemon_Name.Text = enemyPokemon.name;

            Player_Pokemon_Sprite.BackgroundImage = Image.FromFile(playerPokemon.backSpritePath);
            Player_Pokemon_Name.Text = playerPokemon.name;

            Attack_Button_1.Text = $"{playerPokemon.moveSet[0].name}\nPP:{playerPokemon.moveSet[0].powerPoints}";
            Attack_Button_1.BackColor = Decide_Type_Color(playerPokemon.moveSet[0].moveType);

            Attack_Button_2.Text = $"{playerPokemon.moveSet[1].name}\nPP:{playerPokemon.moveSet[1].powerPoints}";
            Attack_Button_2.BackColor = Decide_Type_Color(playerPokemon.moveSet[1].moveType);

            // Picks the enemy pokemon
            Pick_Pokemon();

            originalFormSize = new Rectangle(this.Location.X, this.Location.Y, this.Width, this.Height);
            enemyPokemonOriginalRectangle = new Rectangle(Enemy_Pokemon_Sprite.Location.X, Enemy_Pokemon_Sprite.Location.Y, Enemy_Pokemon_Sprite.Width, Enemy_Pokemon_Sprite.Height);
            enemyNameOriginalRectangle = new Rectangle(Enemy_Pokemon_Name.Location.X, Enemy_Pokemon_Name.Location.Y, Enemy_Pokemon_Name.Width, Enemy_Pokemon_Name.Height);


            // Starts the timer that runs in the background MUST BE LAST THING UPON LOAD
            Updater.Start();
        }

        // Will be ran every tick
        private void Update(object sender, EventArgs e)
        {


            if (!Check_Enemy_Alive())
            {
                Enemy_Pokemon_Sprite.BackgroundImage = null;
                Message_Box.Text = $"Enemy {Enemy_Pokemon_Name.Text} has died";
            }


            // Debug.WriteLine("TICK");
        }



        private void Battle_Menu_Resize(object sender, EventArgs e)
        {

            Resize_Control(enemyPokemonOriginalRectangle, Enemy_Pokemon_Sprite);
            Resize_Control(enemyNameOriginalRectangle, Enemy_Pokemon_Name);
        }

        private void Resize_Control(Rectangle r, Control c)
        {
            float xRatio = (float)(this.Width) / (float)(originalFormSize.Width);
            float yRatio = (float)(this.Height) / (float)(originalFormSize.Height);

            int newX = (int)(r.Location.X * xRatio);
            int newY = (int)(r.Location.Y * yRatio);

            int newWidth = (int)(r.Width * xRatio);
            int newHeight = (int)(r.Height * yRatio);

            c.Location = new Point(newX, newY);
            c.Size = new Size(newWidth, newHeight);
        }

        // Picks either bulbasaur, charmander, or squirtle depending on a rng
        private Pokemon Pick_Pokemon()
        {

            int num = rng.Next(3);

            if (num == 0)
            {
                return new Bulbasaur();
            }
            else if (num == 1)
            {
                return new Charmander();
            }
            else
            {
                return new Squirtle();
            }
        }

        // Exits the program
        private void Exit_Button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Change Pokemon Button
        private void Change_Button_Click(object sender, EventArgs e)
        {
            Pick_Pokemon();
        }

        // Minus health button
        private void Minus_Health_Button_Click(object sender, EventArgs e)
        {
            if (Enemy_Health_Bar.Value >= 10)
            {
                Enemy_Health_Bar.Value -= 10;
            }

        }

        // Heal button
        private void Heal_Button_Click(object sender, EventArgs e)
        {
            Enemy_Health_Bar.Value = Enemy_Health_Bar.Maximum;
            enemyPokemon.health = Enemy_Health_Bar.Value;
        }

        // Checks if the enemy is alive
        private bool Check_Enemy_Alive()
        {

            if (Enemy_Health_Bar.Value <= 0)
            {
                return false;
            }

            return true;
        }


        // Reruns the game
        private void Rerun_Button_Click(object sender, EventArgs e)
        {
            this.Close();
            new Battle_Menu().Show();
        }

        private Color Decide_Type_Color(string type)
        {

            if (type.Equals("Fire"))
            {
                return Color.Red;
            }

            else if (type.Equals("Water"))
            {
                return Color.Blue;
            }

            else if (type.Equals("Grass"))
            {
                return Color.Green;
            }

            else if (type.Equals("Normal"))
            {
                return Color.Gray;
            }

            return Color.White;
        }

        private void Attack_Button_1_Click(object sender, EventArgs e)
        {
            Update_Message_Box_Text(playerPokemon, enemyPokemon, Enemy_Health_Bar, 0);
            Attack_Button_1.Text = $"{playerPokemon.moveSet[0].name}\nPP:{playerPokemon.moveSet[0].powerPoints}";
        }

        private void Attack_Button_2_Click(object sender, EventArgs e)
        {
            Update_Message_Box_Text(playerPokemon, enemyPokemon, Enemy_Health_Bar, 1);
            Attack_Button_2.Text = $"{playerPokemon.moveSet[1].name}\nPP:{playerPokemon.moveSet[1].powerPoints}";
        }

        private void Update_Message_Box_Text(Pokemon user, Pokemon target, ProgressBar targetHealthBar, int attackNumber)
        {
            string message = $"{user.moveSet[attackNumber].Calculate_Type_Effectiveness(target).message}";

            message = !message.Equals("") ? message + $"\n{user.moveSet[attackNumber].Use(user, target, targetHealthBar)}" : $"{user.moveSet[attackNumber].Use(user, target, targetHealthBar)}";

            Message_Box.Text = message;
        }
    }
}

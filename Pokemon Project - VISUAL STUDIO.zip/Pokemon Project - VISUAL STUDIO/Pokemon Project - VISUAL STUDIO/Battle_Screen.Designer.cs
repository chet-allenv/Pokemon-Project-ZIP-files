﻿namespace Pokemon_Project___VISUAL_STUDIO
{
    partial class Battle_Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Battle_Menu));
            Enemy_Pokemon_Sprite = new PictureBox();
            Enemy_Pokemon_Name = new Label();
            Exit_Button = new Button();
            Enemy_Health_Bar = new ProgressBar();
            Change_Button = new Button();
            Minus_Health_Button = new Button();
            Heal_Button = new Button();
            Updater = new System.Windows.Forms.Timer(components);
            Death_Message = new Label();
            Rerun_Button = new Button();
            Attack_Button_1 = new Button();
            Attack_Button_2 = new Button();
            Player_Health_Bar = new ProgressBar();
            Player_Pokemon_Sprite = new PictureBox();
            Player_Pokemon_Name = new Label();
            Message_Box = new Label();
            ((System.ComponentModel.ISupportInitialize)Enemy_Pokemon_Sprite).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Player_Pokemon_Sprite).BeginInit();
            SuspendLayout();
            // 
            // Enemy_Pokemon_Sprite
            // 
            Enemy_Pokemon_Sprite.BackColor = Color.Transparent;
            Enemy_Pokemon_Sprite.BackgroundImageLayout = ImageLayout.Stretch;
            Enemy_Pokemon_Sprite.InitialImage = null;
            Enemy_Pokemon_Sprite.Location = new Point(378, 23);
            Enemy_Pokemon_Sprite.Margin = new Padding(2);
            Enemy_Pokemon_Sprite.Name = "Enemy_Pokemon_Sprite";
            Enemy_Pokemon_Sprite.Size = new Size(208, 193);
            Enemy_Pokemon_Sprite.TabIndex = 2;
            Enemy_Pokemon_Sprite.TabStop = false;
            // 
            // Enemy_Pokemon_Name
            // 
            Enemy_Pokemon_Name.AutoSize = true;
            Enemy_Pokemon_Name.BackColor = Color.Transparent;
            Enemy_Pokemon_Name.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Enemy_Pokemon_Name.Location = new Point(45, 77);
            Enemy_Pokemon_Name.Margin = new Padding(2, 0, 2, 0);
            Enemy_Pokemon_Name.Name = "Enemy_Pokemon_Name";
            Enemy_Pokemon_Name.Size = new Size(104, 20);
            Enemy_Pokemon_Name.TabIndex = 5;
            Enemy_Pokemon_Name.Text = "Enemy Name";
            // 
            // Exit_Button
            // 
            Exit_Button.BackColor = Color.Firebrick;
            Exit_Button.ForeColor = SystemColors.ButtonFace;
            Exit_Button.Location = new Point(10, 11);
            Exit_Button.Name = "Exit_Button";
            Exit_Button.Size = new Size(139, 31);
            Exit_Button.TabIndex = 6;
            Exit_Button.Text = "EXIT";
            Exit_Button.UseVisualStyleBackColor = false;
            Exit_Button.Click += Exit_Button_Click;
            // 
            // Enemy_Health_Bar
            // 
            Enemy_Health_Bar.BackColor = SystemColors.Highlight;
            Enemy_Health_Bar.ForeColor = Color.Transparent;
            Enemy_Health_Bar.Location = new Point(141, 110);
            Enemy_Health_Bar.Name = "Enemy_Health_Bar";
            Enemy_Health_Bar.RightToLeft = RightToLeft.No;
            Enemy_Health_Bar.Size = new Size(132, 10);
            Enemy_Health_Bar.Step = 1;
            Enemy_Health_Bar.TabIndex = 7;
            // 
            // Change_Button
            // 
            Change_Button.Location = new Point(12, 140);
            Change_Button.Name = "Change_Button";
            Change_Button.Size = new Size(76, 40);
            Change_Button.TabIndex = 8;
            Change_Button.Text = "Change Pokemon";
            Change_Button.UseVisualStyleBackColor = true;
            Change_Button.Click += Change_Button_Click;
            // 
            // Minus_Health_Button
            // 
            Minus_Health_Button.Location = new Point(94, 140);
            Minus_Health_Button.Name = "Minus_Health_Button";
            Minus_Health_Button.Size = new Size(75, 40);
            Minus_Health_Button.TabIndex = 9;
            Minus_Health_Button.Text = "Minus 10 Health";
            Minus_Health_Button.UseVisualStyleBackColor = true;
            Minus_Health_Button.Click += Minus_Health_Button_Click;
            // 
            // Heal_Button
            // 
            Heal_Button.Location = new Point(175, 140);
            Heal_Button.Name = "Heal_Button";
            Heal_Button.Size = new Size(75, 38);
            Heal_Button.TabIndex = 10;
            Heal_Button.Text = "HEAL";
            Heal_Button.UseVisualStyleBackColor = true;
            Heal_Button.Click += Heal_Button_Click;
            // 
            // Updater
            // 
            Updater.Tick += Update;
            // 
            // Death_Message
            // 
            Death_Message.AutoSize = true;
            Death_Message.BackColor = Color.Transparent;
            Death_Message.Location = new Point(28, 381);
            Death_Message.Name = "Death_Message";
            Death_Message.Size = new Size(0, 15);
            Death_Message.TabIndex = 11;
            // 
            // Rerun_Button
            // 
            Rerun_Button.BackColor = Color.ForestGreen;
            Rerun_Button.ForeColor = SystemColors.ButtonFace;
            Rerun_Button.Location = new Point(155, 12);
            Rerun_Button.Name = "Rerun_Button";
            Rerun_Button.Size = new Size(134, 30);
            Rerun_Button.TabIndex = 12;
            Rerun_Button.Text = "RERUN";
            Rerun_Button.UseVisualStyleBackColor = false;
            Rerun_Button.Click += Rerun_Button_Click;
            // 
            // Attack_Button_1
            // 
            Attack_Button_1.Location = new Point(364, 396);
            Attack_Button_1.Name = "Attack_Button_1";
            Attack_Button_1.Size = new Size(113, 100);
            Attack_Button_1.TabIndex = 13;
            Attack_Button_1.Text = "Attack 1";
            Attack_Button_1.UseVisualStyleBackColor = true;
            Attack_Button_1.Click += Attack_Button_1_Click;
            // 
            // Attack_Button_2
            // 
            Attack_Button_2.BackColor = SystemColors.Control;
            Attack_Button_2.Location = new Point(497, 396);
            Attack_Button_2.Name = "Attack_Button_2";
            Attack_Button_2.Size = new Size(114, 100);
            Attack_Button_2.TabIndex = 14;
            Attack_Button_2.Text = "Attack 2";
            Attack_Button_2.UseVisualStyleBackColor = false;
            Attack_Button_2.Click += Attack_Button_2_Click;
            // 
            // Player_Health_Bar
            // 
            Player_Health_Bar.Location = new Point(466, 297);
            Player_Health_Bar.Name = "Player_Health_Bar";
            Player_Health_Bar.Size = new Size(136, 14);
            Player_Health_Bar.TabIndex = 15;
            // 
            // Player_Pokemon_Sprite
            // 
            Player_Pokemon_Sprite.BackColor = Color.Transparent;
            Player_Pokemon_Sprite.BackgroundImageLayout = ImageLayout.Stretch;
            Player_Pokemon_Sprite.Location = new Point(49, 203);
            Player_Pokemon_Sprite.Name = "Player_Pokemon_Sprite";
            Player_Pokemon_Sprite.Size = new Size(240, 167);
            Player_Pokemon_Sprite.TabIndex = 16;
            Player_Pokemon_Sprite.TabStop = false;
            // 
            // Player_Pokemon_Name
            // 
            Player_Pokemon_Name.AutoSize = true;
            Player_Pokemon_Name.BackColor = Color.Transparent;
            Player_Pokemon_Name.Font = new Font("Segoe UI", 12F);
            Player_Pokemon_Name.Location = new Point(378, 264);
            Player_Pokemon_Name.Name = "Player_Pokemon_Name";
            Player_Pokemon_Name.Size = new Size(99, 21);
            Player_Pokemon_Name.TabIndex = 17;
            Player_Pokemon_Name.Text = "Player Name";
            // 
            // Message_Box
            // 
            Message_Box.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Message_Box.Location = new Point(28, 396);
            Message_Box.Name = "Message_Box";
            Message_Box.Size = new Size(306, 100);
            Message_Box.TabIndex = 18;
            Message_Box.Text = "THIS IS PLACEHOLDER TEXT";
            // 
            // Battle_Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(645, 530);
            Controls.Add(Message_Box);
            Controls.Add(Player_Pokemon_Name);
            Controls.Add(Player_Pokemon_Sprite);
            Controls.Add(Player_Health_Bar);
            Controls.Add(Attack_Button_2);
            Controls.Add(Attack_Button_1);
            Controls.Add(Rerun_Button);
            Controls.Add(Death_Message);
            Controls.Add(Heal_Button);
            Controls.Add(Minus_Health_Button);
            Controls.Add(Change_Button);
            Controls.Add(Enemy_Health_Bar);
            Controls.Add(Exit_Button);
            Controls.Add(Enemy_Pokemon_Name);
            Controls.Add(Enemy_Pokemon_Sprite);
            Margin = new Padding(2);
            Name = "Battle_Menu";
            Text = "Pokemon Project";
            Load += Form1_Load;
            Resize += Battle_Menu_Resize;
            ((System.ComponentModel.ISupportInitialize)Enemy_Pokemon_Sprite).EndInit();
            ((System.ComponentModel.ISupportInitialize)Player_Pokemon_Sprite).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox Enemy_Pokemon_Sprite;
        private Label Enemy_Pokemon_Name;
        private Button Exit_Button;
        private ProgressBar Enemy_Health_Bar;
        private Button Change_Button;
        private Button Minus_Health_Button;
        private Button Heal_Button;
        private System.Windows.Forms.Timer Updater;
        private Label Death_Message;
        private Button Rerun_Button;
        private Button Attack_Button_1;
        private Button Attack_Button_2;
        private ProgressBar Player_Health_Bar;
        private PictureBox Player_Pokemon_Sprite;
        private Label Player_Pokemon_Name;
        private Label Message_Box;
    }
}

﻿using System;

namespace Pokemon_Project___VISUAL_STUDIO
{

    public class Pokemon
    {

        public string name { get; set; }
        public string frontSpritePath { get; set; }
        public string backSpritePath { get; set; }
        public int attack { get; set; }
        public int defense { get; set; }
        public int special { get; set; }
        public int speed { get; set; }
        public int health { get; set; }
        public int level { get; set; }
        public string type { get; set; }

        public Attack[] moveSet;

        private readonly Random rng = new();

        public Pokemon(string name, string frontSpritePath, string backSpritePath, string type, int level)
        {

            this.name = name;
            this.frontSpritePath = frontSpritePath;
            this.backSpritePath = backSpritePath;
            this.attack = Generate_Stat();
            this.defense = Generate_Stat();
            this.special = Generate_Stat();
            this.speed = Generate_Stat();
            this.health = Generate_Stat(30, 70);
            this.level = level;
            this.type = type;

            moveSet = new Attack[2];
        }

        private int Generate_Stat(int low = 5, int high = 25)
        {
            return rng.Next(low, high) + 2 * (2 * this.level / 5 + 2);
        }

        public bool Is_Alive() { return this.health > 0; }

        public void Attack(int attackNumber, Pokemon target, ProgressBar targetHealthBar)
        {
            moveSet[attackNumber].Use(this, target, targetHealthBar);
        }
    }

    public class Charmander : Pokemon
    {

        public Charmander() : base("Charmander", "Images\\charmander.png", "Images\\charmander_back.png", "Fire", 5)
        {
            moveSet = [new Tackle_Attack(), new Ember_Attack()];
        }
    }

    public class Squirtle : Pokemon
    {

        public Squirtle() : base("Squirtle", "Images\\squirtle.png", "Images\\squirtle_back.png", "Water", 5)
        {
            moveSet = [new Tackle_Attack(), new Bubble_Attack()];
        }
    }

    public class Bulbasaur : Pokemon
    {

        public Bulbasaur() : base("Bulbasaur", "Images\\bulbasaur.png", "Images\\bulbasaur_back.png", "Grass", 5)
        {
            moveSet = [new Tackle_Attack(), new Vine_Whip_Attack()];
        }
    }

}
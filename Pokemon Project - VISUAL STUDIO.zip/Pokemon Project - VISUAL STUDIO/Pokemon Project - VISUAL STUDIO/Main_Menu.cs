﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pokemon_Project___VISUAL_STUDIO
{
    public partial class Main_Menu : Form
    {

        // Size variables

        private Rectangle playButtonOriginalRectangle;
        private Rectangle quitButtonOriginalRectangle;    
        private Rectangle originalFormSize;

        public Main_Menu()
        {
            InitializeComponent();

        }

        private void Main_Menu_Load(object sender, EventArgs e)
        {   

            // Sets the size of the Form and the components

            originalFormSize = new Rectangle(this.Location.X, this.Location.Y, this.Width, this.Height);
            playButtonOriginalRectangle = new Rectangle(playButton.Location.X, playButton.Location.Y, playButton.Width, playButton.Height);
            quitButtonOriginalRectangle = new Rectangle(quitButton.Location.X, quitButton.Location.Y, quitButton.Width, quitButton.Height);
        }

        // This is called when the form is resized
        private void Main_Menu_Resize(object sender, EventArgs e)
        {   
            // Resizes the buttons accordingly
            Resize_Control(playButtonOriginalRectangle, playButton);
            Resize_Control(quitButtonOriginalRectangle, quitButton);
        }

           
        // This function resizes the controls in relation to the form theyre on.
        private void Resize_Control(Rectangle r, Control c)
        {
            float xRatio = (float)(this.Width) / (float)(originalFormSize.Width);
            float yRatio = (float)(this.Height) / (float)(originalFormSize.Height);

            int newX = (int)(r.Location.X * xRatio);
            int newY = (int)(r.Location.Y * yRatio);

            int newWidth = (int)(r.Width * xRatio);
            int newHeight = (int)(r.Height * yRatio);

            c.Location = new Point(newX, newY);
            c.Size = new Size(newWidth, newHeight);
        }

        // When the play button is clicked
        private void Play_Button_Click(object sender, EventArgs e)
        {
            Play_Game();
        }


        // This function switches scenes
        private void Play_Game()
        {
            this.Close();
            new Battle_Menu().Show();

        }

        // Quits the game
        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        
    }
}

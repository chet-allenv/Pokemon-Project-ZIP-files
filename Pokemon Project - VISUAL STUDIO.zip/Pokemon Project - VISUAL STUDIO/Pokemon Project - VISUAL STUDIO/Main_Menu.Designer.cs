﻿namespace Pokemon_Project___VISUAL_STUDIO
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Menu));
            playButton = new Button();
            quitButton = new Button();
            SuspendLayout();
            // 
            // playButton
            // 
            playButton.BackgroundImage = (Image)resources.GetObject("playButton.BackgroundImage");
            playButton.BackgroundImageLayout = ImageLayout.Stretch;
            playButton.Location = new Point(184, 309);
            playButton.Margin = new Padding(2);
            playButton.Name = "playButton";
            playButton.Size = new Size(293, 95);
            playButton.TabIndex = 0;
            playButton.UseVisualStyleBackColor = true;
            playButton.Click += Play_Button_Click;
            // 
            // quitButton
            // 
            quitButton.BackgroundImage = (Image)resources.GetObject("quitButton.BackgroundImage");
            quitButton.BackgroundImageLayout = ImageLayout.Stretch;
            quitButton.Location = new Point(184, 422);
            quitButton.Margin = new Padding(2);
            quitButton.Name = "quitButton";
            quitButton.Size = new Size(293, 76);
            quitButton.TabIndex = 1;
            quitButton.UseVisualStyleBackColor = true;
            quitButton.Click += quitButton_Click;
            // 
            // Main_Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(645, 530);
            Controls.Add(quitButton);
            Controls.Add(playButton);
            Margin = new Padding(2);
            Name = "Main_Menu";
            Text = "Pokemon Project";
            Load += Main_Menu_Load;
            Resize += Main_Menu_Resize;
            ResumeLayout(false);
        }

        #endregion

        private Button playButton;
        private Button quitButton;
    }
}